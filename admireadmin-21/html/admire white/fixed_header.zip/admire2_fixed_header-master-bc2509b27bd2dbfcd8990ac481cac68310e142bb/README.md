#Admire admin theme
======

##fonts used: Raleway

#font sizes:
	a. regular content font size-> 13px
	b. panel heading font size->16px

text-color: white


##colors

		Default		Primary		Success		Info		Warning		Danger		Mint		Gray


Bg - Color	#2c2c2c		#75c1e4		#a7ce5a		#bd7bde		#ffb25a		#de5a5a		#69d3bf		#bac4c5

Lite Color 	#424242		#2a9fd6		#77b300		#9933cc		#ff8800		#cc0000		#18bc9c		#95a5a6

Dark Color	#282828		#2180ac		#558000		#7a29a3		#cc6000		#990000		#128f76		#798d8f	

Text Color	#282828		#2180ac		#558000		#7a29a3		#cc6000		#990000		#128f76		#798d8f

Border -color   #424242		#2a9fd6		#77b300		#9933cc		#ff8800		#cc0000		#18bc9c		#95a5a6






